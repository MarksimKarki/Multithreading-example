package Resources;

import java.util.Scanner;

public class InputClass {
	public static Scanner input=new Scanner(System.in);
}
